export interface users{
    userId: number;
    first_name: string;
    last_name: string;
    mobile_no:number;
    age:number;
    username:string;
    password: string;
    gender:string;
    }
    