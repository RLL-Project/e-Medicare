export class Contact {
    name!: string;
    emailId!: string;
    contactNo!: number;
    description!: string;
}
